#!/bin/bash

case "$1" in
	pre) : ;;
	post) : ;;
	end) : ;;
esac

exit 0
